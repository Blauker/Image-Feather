Image-Feather
- This program will change the extension of all your images to '.jpg' and will reduce que quality to compress the file size.
- Really usefull when you need to send tons of heavy images or your net is slow.

How to install
- Download the .zip file and extract it on a folder wherever you want on your PC.
- Open "Image Feather.exe" file (I'd recommend to you to create a shortcut into your desktop)
- Select the quality reduction from the slider.
- Select the folder when you hold the images to compress.
NOTE: the new images will be saved (replaced) on the same folder.

Credits
- Developed by Blauker (me).
- App design is a modification of Tom Schimansky's CustomTkinter template.
- Special thanks to my Girlfriend who was in call with me all the night & StackOverflow D:

DO NOT SELL OR DISTRIBUTE THIS APP BY YOUR OWN; IF YOU WANT TO SHARE IT, ALWAYS SEND THE GITHUB REPO.
https://github.com/Blauker/Image-Feather

